create procedure update_department(IN emp_id integer)
    language plpgsql
as
$$
    BEGIN
        update employees set department = 'Toys'
        where employee_id = emp_id;
        commit ;
    end;
    $$;

alter procedure update_department(integer) owner to postgres;

