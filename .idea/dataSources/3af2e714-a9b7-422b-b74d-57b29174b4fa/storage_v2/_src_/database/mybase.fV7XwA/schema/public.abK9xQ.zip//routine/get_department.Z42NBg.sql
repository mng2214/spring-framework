create function get_department(p_pattern character varying)
    returns TABLE(employee_name character varying, employee_email character varying)
    language plpgsql
as
$$
BEGIN
  return query
    select first_name, email
    from employees
    where department ilike  p_pattern;
end;
$$;

alter function get_department(varchar) owner to postgres;

